--@name Santa Fe Way (video frames)
--@author
--@client

-- Plays through the game screens taken from your video.
-- 1) Upload the frames/ folder (001.jpg ... 183.jpg) to a host Starfall allows
--    (GitHub repo raw links, Imgur, Discord CDN, Dropbox, etc.).
-- 2) Set BASE below to the folder URL, ending in a slash. Example:
--    "https://raw.githubusercontent.com/YOURNAME/santafe/main/frames/"
-- 3) Link chip -> Starfall screen. Look at the screen:
--    Left click = next screen | Right click = back | R = restart

local BASE  = "https://raw.githubusercontent.com/YOURNAME/santafe/main/frames/"
local COUNT = 183

local W, H = 512, 512
local fSm = render.createFont("Roboto", 16, 600, true)

local idx = 1
local mats = {}
local cx, cy

local function url(i) return BASE .. string.format("%03d", i) .. ".jpg" end

local function want(i)
    if i < 1 or i > COUNT or mats[i] then return end
    local m = material.create("UnlitGeneric")
    m:setTextureURL("$basetexture", url(i))
    mats[i] = m
end

local function unloadFar()
    for i in pairs(mats) do
        if math.abs(i - idx) > 4 then
            mats[i]:destroy()
            mats[i] = nil
        end
    end
end

local function go(d)
    idx = math.clamp(idx + d, 1, COUNT)
    unloadFar()
end

hook.add("render", "sfw_video", function()
    cx, cy = render.cursorPos()

    render.setColor(Color(0, 0, 0))
    render.drawRect(0, 0, W, H)

    for i = idx, idx + 2 do want(i) end
    want(idx - 1)

    -- 16:9 frame centered on the 512x512 screen
    local fw, fh = W, W * 9 / 16
    local fy = (H - fh) / 2

    local m = mats[idx]
    if m then
        render.setColor(Color(255, 255, 255))
        render.setMaterial(m)
        render.drawTexturedRect(0, fy, fw, fh)
    else
        render.setColor(Color(255, 255, 255))
        render.setFont(fSm)
        render.drawSimpleText(W / 2, H / 2, "Loading " .. idx .. "...", TEXT_ALIGN.CENTER, TEXT_ALIGN.CENTER)
    end

    render.setColor(Color(255, 255, 255, 200))
    render.setFont(fSm)
    render.drawSimpleText(8, H - 24, idx .. " / " .. COUNT .. "   L-click next  R-click back  R restart", TEXT_ALIGN.LEFT, TEXT_ALIGN.TOP)

    if cx then
        render.setColor(Color(255, 255, 255))
        render.drawRect(cx - 3, cy - 3, 6, 6)
    end
end)

hook.add("inputPressed", "sfw_input", function(key)
    if not cx then return end
    if key == MOUSE.MOUSE1 then go(1)
    elseif key == MOUSE.MOUSE2 then go(-1)
    elseif key == KEY.R then idx = 1; unloadFar() end
end)
