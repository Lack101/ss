Santa Fe Way - GMod Starfall package

frames/                    183 game screens pulled from your video, in play order (001.jpg ...)
santa_fe_way_video.lua     the Starfall script

Steps:
1. Put the frames folder on a host Starfall can load from (GitHub raw is easiest).
2. Edit BASE at the top of the script to that folder's URL (end with /).
3. In GMod: spawn a Starfall chip and a Starfall screen, link them, upload the script.
4. Look at the screen: left click = next, right click = back, R = restart.
